#!/usr/bin/env python3
"""Generate the subset-sum corpus for this branch's tier.

Each question is N positive integers of DIGITS digits and a target equal to
the sum of a hidden SUBSET_SIZE-element subset. Public instances are written
to data/public/<tier>/, the answer key to data/private/<tier>/ (gitignored).

Deterministic: question q uses random.Random(BASE_SEED + q).
"""
from __future__ import annotations

import hashlib
import json
import os
import random
from pathlib import Path

TIER = "n60d10"
N = 60
SUBSET_SIZE = 30
DIGITS = 10
QUESTIONS = 100
BASE_SEED = 20260903
VALUE_LO, VALUE_HI = 10 ** (DIGITS - 1), 10 ** DIGITS - 1
ROOT = Path(__file__).resolve().parents[1]
RUNNER_TEMP = os.environ.get("RUNNER_TEMP", "/home/runner/work/_temp")
GEN_LOG = Path(RUNNER_TEMP) / "generation" / (
    f"gen-{BASE_SEED}-{hashlib.sha256(TIER.encode()).hexdigest()[:4]}.log"
)


def format_instance(name: str, numbers: list[int], target: int) -> str:
    lines = [f"NAME: {name}", "TYPE: SUBSET_SUM", f"DIMENSION: {len(numbers)}",
             f"TARGET: {target}", "NUMBERS_SECTION", *[str(v) for v in numbers], "EOF"]
    return "\n".join(lines) + "\n"


def make_question(q: int) -> tuple[dict, dict, str]:
    seed = BASE_SEED + q
    rng = random.Random(seed)
    task_id = f"subsetsum_n60d10_{q}"
    numbers = [rng.randint(VALUE_LO, VALUE_HI) for _ in range(N)]
    indices = sorted(rng.sample(range(N), SUBSET_SIZE))
    target = sum(numbers[i] for i in indices)
    sha = hashlib.sha256(format_instance(task_id, numbers, target).encode()).hexdigest()
    public = {"task_id": task_id, "category": "subset_sum", "dimension": N,
              "instance_sha256": sha,
              "instance": {"format": "subset_sum_v1", "name": task_id,
                           "target": target, "numbers": numbers}}
    oracle = {"task_id": task_id, "dimension": N, "target": target,
              "solution_indices": indices, "instance_sha256": sha}
    audit = f"{task_id} seed={seed} target={target} solution_indices={json.dumps(indices)}\n"
    return public, oracle, audit


def main() -> None:
    pub_dir = ROOT / "data" / "public" / TIER
    priv_dir = ROOT / "data" / "private" / TIER
    (priv_dir / "solutions").mkdir(parents=True, exist_ok=True)
    pub_dir.mkdir(parents=True, exist_ok=True)
    GEN_LOG.parent.mkdir(parents=True, exist_ok=True)
    oracles = []
    with GEN_LOG.open("a", encoding="utf-8") as log:
        log.write(f"# generation log: tier {TIER} n={N} subset={SUBSET_SIZE} "
                  f"digits={DIGITS} base_seed={BASE_SEED}\n")
        for q in range(1, QUESTIONS + 1):
            public, oracle, audit = make_question(q)
            (pub_dir / f"{public['task_id']}.json").write_text(json.dumps(public) + "\n")
            (priv_dir / "solutions" / f"{public['task_id']}.txt").write_text(
                f"# exact subset for {public['task_id']} - sums to target {oracle['target']}\n"
                + " ".join(str(i) for i in oracle["solution_indices"]) + "\n")
            oracles.append(oracle)
            log.write(audit)
    (priv_dir / "oracles.jsonl").write_text("".join(json.dumps(o) + "\n" for o in oracles))
    print(f"wrote {QUESTIONS} questions to {pub_dir} and {priv_dir}; audit at {GEN_LOG}")


if __name__ == "__main__":
    main()
