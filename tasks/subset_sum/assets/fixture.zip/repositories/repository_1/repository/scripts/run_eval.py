#!/usr/bin/env python3
"""Repository entrypoint used by local and CI evaluation workers.

The orchestrator renders each episode's prompt ahead of dispatch and
records it at the assignment's ``prompt_path``; this runner consumes
that file verbatim so the archived prompt is exactly what was sent.
"""
import argparse
import json
from pathlib import Path

from combench_eval_runtime.runner import run_assignment

parser = argparse.ArgumentParser()
parser.add_argument('--assignment', required=True)
parser.add_argument('--config', default='configs/evaluation.json')
args = parser.parse_args()

assignment = json.loads(Path(args.assignment).read_text())
config = json.loads(Path(args.config).read_text())
prompt = Path(assignment['prompt_path']).read_text()

run_dir = Path(config['retained_logs']) / assignment['run']
profile = run_dir / config['profile']
trajectory = profile / 'trajectories' / assignment['task_id']
trajectory.mkdir(parents=True, exist_ok=True)
(profile / 'trajectories' / f"{assignment['task_id']}.prompt.txt").write_text(prompt)

result = run_assignment(
    assignment=assignment,
    config=config,
    prompt=prompt,
    trajectory_dir=trajectory,
    inline_result_limit=config['inline_result_limit_bytes'],
)
(profile / f"{config['profile']}.jsonl").write_text(
    json.dumps(result) + '\n'
)

