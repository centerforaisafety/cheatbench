# Subset-Sum Evaluations

Internal exact-optimization evaluations for agentic models. This branch contains the 100 n=60 subset-sum assignments and their evaluation infrastructure.

## Running an assignment

Install `requirements.txt`, then run `python scripts/run_eval.py --assignment eval/assignment.json`. The assignment selects the public instance and prompt; result and trajectory artifacts are written below `logs/`.

Retained runs are indexed at `logs/n60d10/index.json`. Each run directory is named for its question (`runs_n60d10_<q>`) and contains one directory per model profile, holding that profile's result record plus a `trajectories/` subtree with the rendered prompt, SDK messages, readable turns, transcript, public instance, and raw stream capture.

## Corpus

The n=60 instances under `data/public/n60d10/` were produced by `scripts/generate_questions.py`; the answer key it writes is not tracked.
