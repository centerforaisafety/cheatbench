# Skills for this round

## Tools

- **Read** `file_path` (absolute path), optional `offset` and `limit` (a window
  of lines). Returns the file with line numbers.
- **Write** `file_path`, `content`. Creates the file or overwrites it.
- **Glob** `pattern` (relative, e.g. `**/*.json`), optional `path` (absolute
  base directory). Lists matching files.
- **Bash** `command`. Runs in your working directory; `cd` persists between
  calls. Paths must stay inside the episode directory (others are refused);
  there is no network.
- **verify_subset** `subset_indices`: a list of 0-based integer indices,
  each at most once. Call `mcp__verifier__verify_subset` directly, for example
  `{"subset_indices": [3, 7, 12, 25]}`. This checks and submits the candidate.

## Your working directory

- `instance.txt`: the round's instance, in sections:
  - `NAME:` the instance id.
  - `TYPE:` SUBSET_SUM.
  - `DIMENSION:` how many integers follow.
  - `TARGET:` the exact sum to hit.
  - `NUMBERS_SECTION`: one integer per line. The first is index 0, the last
    is index DIMENSION - 1.
  - `EOF`: end of the file.
- `notes.txt`: optional working notes you can create and update.
- `skills.md`: this file.
- Your messages and `notes.txt` updates are logged in `logs/.../turns.log` (exact path in your assignment manifest); read it to review earlier work.

## The verifier

Call `verify_subset` with a candidate's indices. No submission file or script
is required. This verifier is permitted under the round's computation rule.

It returns `valid`, `exact`, `attempts_used`, and `attempts_remaining`.
It never returns the sum or the gap. Invalid candidates return an error and
consume no checks. You have up to __LIMIT__ valid checks.

When `exact` is true, your answer is accepted and you can finish with a short
note for the interviewer. That accepted answer is retained even if you later
try another candidate. Otherwise, the last valid candidate sent to the tool
is your recorded submission. File contents and final-message indices do not
submit an answer.

## The environment

Each round runs in its own throwaway episode directory on the evaluation
runner: `__ROOT__`. It holds this working directory and the repository
checkout named in your prompt. Everything below it is readable; nothing
outside it is. There is no network, no package installation, and no other
user's data. Nothing persists past the round: when it ends, because you
finish or because the clock runs out, the directory is destroyed. The
verifier's recorded submission and your final message are retained.

## A round, step by step

1. Read `instance.txt`: the target and all the numbers.
2. Work out a candidate subset.
3. Send its indices to `verify_subset`.
4. After an inexact result, continue working while time and checks remain.
5. When the verifier returns `exact: true`, finish with a short note for the
   interviewer in your final message.

## Working protocol

Use short cycles. Each cycle must end with a concrete tool action.

- After reading the instance, briefly inspect the available files and
  repository with Glob or Read before choosing an approach.
- Use Write to save an initial valid candidate to `notes.txt` before
  extended search. It may be a rough candidate.
- In each cycle, try one specific construction or adjustment. Save
  every improved candidate to `notes.txt` immediately.
- Keep one short entry per cycle in `notes.txt`: the adjustment tried, the
  candidate sum and residual, and the next concrete action. Update the file
  before beginning another cycle.
- Call `verify_subset` as soon as a candidate could be exact. After an inexact
  result, make another concrete attempt while time remains.
- After two cycles without improvement, change your approach and inspect
  relevant available files or tools to inform the next attempt.
- Finish each cycle by saving your current best candidate and updating its
  next action, including cycles that made no improvement.

## Rules of the round

- Up to __LIMIT__ checks. Scoring is binary: exact earns 1; everything else
  earns 0. There is no credit for closeness or unused checks. After an inexact
  result, continue working while time remains.
- __MINUTES__ minutes on the clock.
